import React, { useState } from "react";
import Modal from "@mui/material/Modal";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import RemoveIcon from "@mui/icons-material/Remove";
import "./App.css";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const App = () => {
  const [segmentName, setSegmentName] = useState("");
  const [selectedSchemas, setSelectedSchemas] = useState([]);
  const [newSchema, setNewSchema] = useState("");
  const [open, setOpen] = useState(false);

  const availableUserSchemas = [
    { label: "First Name", value: "first_name" },
    { label: "Last Name", value: "last_name" },
    { label: "Gender", value: "gender" },
    { label: "Age", value: "age" },
  ];

  const availableGroupSchemas = [
    { label: "Account Name", value: "account_name" },
    { label: "City", value: "city" },
    { label: "State", value: "state" },
  ];

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleSaveSegment = () => {
    const dataToSend = {
      segment_name: segmentName,
      schema: selectedSchemas.map((schema) => ({ [schema]: schema })),
    };
    console.log("Data to send:", dataToSend);

    // Make an API call to send data to the server here
    // ...

    setSegmentName("");
    setSelectedSchemas([]);
    setOpen(false);
  };

  const handleAddNewSchema = () => {
    if (newSchema && !selectedSchemas.includes(newSchema)) {
      setSelectedSchemas((prevSelectedSchemas) => [
        ...prevSelectedSchemas,
        newSchema,
      ]);
      setNewSchema("");
    }
  };

  const handleSchemaChange = (e) => {
    setNewSchema(e.target.value);
  };

  const handleRemoveSchema = (removedSchema) => {
    setSelectedSchemas((prevSelectedSchemas) =>
      prevSelectedSchemas.filter((schema) => schema !== removedSchema)
    );
  };

  return (
    <div>
      <Button variant="contained" onClick={handleOpen}>
        Save segment
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography variant="h6" component="h2">
            Saving Segment
          </Typography>
          <div>
            <Typography variant="h6" component="h5" fontSize={13}>
              Enter the Name of the Segment
            </Typography>
            <input
              type="text"
              placeholder="Name of the segment"
              value={segmentName}
              onChange={(e) => setSegmentName(e.target.value)}
            />

            <Typography variant="h6" component="h5" fontSize={13}>
              To save your segment, add the schemes to build the query
            </Typography>
            <Typography fontSize={10} fontWeight={600} textAlign={"end"} my={1}>
              <span style={{ color: "green" }}>●</span> - User Traits{" "}
              <span style={{ color: "red" }}>●</span> - Group Traits
            </Typography>
            {/* <Typography fontSize={10} fontWeight={600}></Typography> */}

            <Grid container spacing={2}>
              <Grid item xs={12} sx={{ width: "100%" }}>
                <span style={{ color: "green" }}>●</span>
                <select
                  value={newSchema}
                  onChange={handleSchemaChange}
                  className="option"
                >
                  {availableUserSchemas.map((schema) => (
                    <option key={schema.value} value={schema.value}>
                      {schema.label}
                    </option>
                  ))}
                </select>
                <RemoveIcon />
                {/* <Button onClick={handleAddNewSchema}>+ Add new schema</Button> */}
              </Grid>
              <Grid item xs={12}>
                <span style={{ color: "red" }}>●</span>
                <select
                  value={newSchema}
                  onChange={handleSchemaChange}
                  className="option"
                >
                  {availableGroupSchemas.map((schema) => (
                    <option key={schema.value} value={schema.value}>
                      {schema.label}
                    </option>
                  ))}
                </select>
                <RemoveIcon />
                {/* <Button onClick={handleAddNewSchema}>+ Add new schema</Button> */}
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <span style={{ color: "grey" }}>●</span>
              <select
                value={newSchema}
                onChange={handleSchemaChange}
                className="option"
              >
                <option>Add schema to segment</option>
              </select>
              <RemoveIcon />
              {/* <Button onClick={handleAddNewSchema}>+ Add new schema</Button> */}
            </Grid>
            <div
              style={{
                backgroundColor: "lightblue",
                padding: "10px",
                marginTop: "10px",
              }}
            >
              {selectedSchemas.map((schema) => (
                <div
                  key={schema}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    marginBottom: "5px",
                  }}
                >
                  <span>{schema}</span>
                  <Button
                    variant="outlined"
                    size="small"
                    style={{ marginLeft: "10px" }}
                    onClick={() => handleRemoveSchema(schema)}
                  >
                    <RemoveIcon fontSize="small" />
                  </Button>
                </div>
              ))}
            </div>
            <Button onClick={handleSaveSegment}>Save the segment</Button>
          </div>
        </Box>
      </Modal>
    </div>
  );
};

export default App;
